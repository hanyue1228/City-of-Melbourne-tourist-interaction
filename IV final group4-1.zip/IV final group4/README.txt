## Get Started

This is an operation guide for the interfaces designed for tourists visiting Melbourne. Please follow the steps below to interact with the pages. Wish you a pleasant user experience.
First, find the tab1&tab3.R file and run it with RStudio, then the user will be guided to the corresponding interface. Then minimize this interface, find the Tab combined.twb file, and run it in Tableau.

## Connect to the data source

If an error message pops up after opening the Tab combined.twb file, displaying 'there was a problem connecting to the data source <name of that data source>'. You need to find the file in the folder and configure it. Firstly, close the pop-up window for this error message, and it will automatically redirect to the current folder directory. Find the corresponding data source file and click open to complete the data source path configuration. Or find the dashboard that reported the error. On the problematic dashboard, the corresponding error message will be displayed. Click on the locate file or edit connection button provided on the error message, then find and select the corresponding data source file, and click open to configure the data source file correctly.

## Dashboard 1

Select Dashboard 1 and enter presentation mode to browse. In this dashboard, Melbourne Daily Solar Exposure Calendar, Melbourne Daily Maximum Temperature Calendar, Melbourne Daily Rainfall Calendar, and Melbourne monthly climate trends are displayed.
For these three calendar heatmaps, we can adjust the corresponding filter bar in the upper left corner to select the corresponding month's information.
The solar exposure, maximum temperature, and rainfall of Melbourne every day in 2023 are displayed on the calendar as a group by month. In addition, the color depth of each circle corresponds to the high and low of the measured data. The darker the color, the higher the corresponding data. If the user is interested in specific weather information for a certain day, simply drag the mouse to the specific date on the calendar, and the specific weather data for that day will be displayed.

The Melbourne monthly climate trends on the right side of dashboard 1 show the monthly changes in solar exposure, maximum temperature, and rainfall in the form of an area chart. Similarly, users can select the month of interest through the filter bar in the upper right corner, or drag the mouse to a specific date to display the specific data of the corresponding date.

## Navigation

Clicking the next page button in the dashboard will jump to the next dashboard. However, users cannot jump back to the previous dashboard through the navigation button. The navigation button of dashboard 3 will guide the user to navigate to dashboard 1.

## Dashboard 2

The interface made in R language is displayed in dashboard 2. If clicking the interface does not respond or the interface is gray, right-click the mouse, and select reload page.
If the interface still does not respond. Users need to re-run the tab1&tab3.R file with RStudio, then minimize the jump page, then return to dashboard 2, right-click the mouse and select reload page.

Dashboard 2 presents two tab interfaces, showing an interactive Melbourne map and an interactive 7-day itinerary list.

**Map**
Enter a valid starting point and destination address on the Melbourne map page, and click the Get Directions button to jump to Google Maps. Google Maps will display the best route based on the starting and ending points that users just entered. Users can select a travel mode to choose the route that suits them.

The control panel on the left side of the map also provides three filter tools, which can filter facilities, transportation, and the top 10 locations.

Select facilities, and then select the type of facility the user wants to know according to their requirements to display all the corresponding facility icons within Melbourne on the map.
For example, if the toilet type is selected, the map will display all toilet icons. Drag the mouse to the icon to display the toilet number and address; click the icon to display whether the toilet includes men's and women's toilets and whether it provides disability facilities.

Select transportation, and then select the type of transportation that the user is interested in according to their requirements to display all the corresponding transportation icons within Melbourne on the map. 
For instance, if the tram type is selected, the map will display different route stations with circles of different colors. The user can click the "+" button in the upper left corner of the map to zoom in on the map. Drag the mouse over the icon to display the corresponding route number; click the icon to display the stop name, stop address, and ticket zone.

Select the top 10 locations to display the icons of the top 10 recommended places to visit when traveling to Melbourne. Drag the mouse over the icon to display the corresponding place name; click the icon to display the place ranking, number of visitors, and a brief description.

**Trip details**
This page displays a 7-day Melbourne itinerary for reference by default. The filter on the left can switch the number of days the user wants to view. After selecting, it will display the recommended tourist attractions for the day. Each attraction name contains a hyperlink, and clicking the name will jump to the corresponding official website. 
Selecting Expenditure will display a pie chart of the annual expenditure in Australia. Drag the mouse over the corresponding pie to display the specific expenditure amount for reference by tourists traveling to Melbourne.

**Return from hyperlink**
After jumping from the itinerary page to the official website of the attraction, close the window, you will find that the dashboard can not be displayed properly, use ctrl+z or command+z to refresh the dashboard page.

## Dashboard 3

Dashboard 3 shows the Melbourne Restaurant Guide: Top 100, Melbourne Cuisine Diversity Bubble map, and Cuisine Popularity and Ratings.

**Melbourne Restaurant Guide: Top 100**
Selecting the filter on the right side of the table, users can filter the restaurants that they are interested in by restaurant name, cuisine, ratings, and price level. The table will also display the restaurant ranking and address, which is convenient for tourists to find the restaurant location.
Clicking on a cell in any row of the table will display a window prompting to jump to that restaurant. Clicking on the hyperlink in the pop-up window will navigate to a map showing the location of the specific restaurant.

**Melbourne Cuisine Diversity Bubble map**
In the Melbourne Cuisine Diversity Bubble map, bubbles of different colors and sizes represent the proportion of restaurants with different flavors. Drag the mouse over each bubble to display the number of restaurants with that flavor and the average rating.

**Cuisine Popularity and Ratings**
The Cuisine Popularity and Ratings bar chart lists the different ratings received by restaurants with different flavors. Each bar displays the proportions of ratings 4, 4.5, and 5 in different colors. Drag the mouse over different bars to observe the rating, number of ratings, and specific information about the restaurant flavor.

## Dashboard 4

Dashboard 4 displays the Melbourne Airbnb Guide, the bubble chart of the average rating of Airbnb by region, the line chart of the average accommodation price for 5 nights in the region, and the tree map of the number of Airbnbs in the region.

**Melbourne Airbnb Guide**
By manipulating the filters, users can filter the Airbnbs they are interested in by rating, price, and region. The table also shows the number of bedrooms and bed sizes for users to get more detailed information.

**Average Rating of Airbnb by Region**
In the bubble chart of the average rating of Airbnb by region, different colors and bubble sizes represent different rating and review numbers. By playing with the filters, users can filter the elements in this chart as well. By moving the mouse on the bubble, the detailed rating and review numbers will pop up.

**Average Accommodation Price (5 Nights) in the Region**
In the line chart (Average Accommodation Price in the Region), the chart is sorted by the average price users can directly see the region with the highest and lowest price of the accommodation.

**Number of Airbnb in the Region**
In the tree map (Number of Airbnb in the Region), different colors and block sizes represent the different Airbnb numbers. By moving the mouse on the region block, the exact number of Airbnb in that region will prompt out.