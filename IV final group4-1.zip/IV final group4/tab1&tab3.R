library(leaflet)
library(shiny)
library(dplyr)
library(sf)
library(RColorBrewer)
library(tidyverse)
library(plotly)
library(viridis)

# Read and load all datasets required
toilet_data <- read.csv("public-toilets.csv")
data <- read.csv("cafes-and-restaurants-with-seating-capacity.csv")
dataset <- read.csv("business-establishments-with-address-and-industry-classification.csv")
carpark_data <- read.csv("off-street-car-parks-with-capacity-and-type.csv")
restaurant_data <- read.csv("Top-100-restaurant-in-melbourne.csv")
# Filter the carpark data 
carpark_data_filtered <- carpark_data %>% 
  filter(CLUE.small.area == "Melbourne (CBD)" & Parking.type != "Private")
# Filter the accommodation data
accommodation_data <- data %>%
  filter(census_year == 2022 & clue_small_area == "Melbourne (CBD)" &
           industry_anzsic4_description == "Accommodation")
# Find the travel agency data
tour_agency_data <- dataset %>%
  filter(Industry..ANZSIC4..description == "Travel Agency and Tour Arrangement Services")

# Find the shop data
shop_data <- dataset %>%
  filter(Industry..ANZSIC4..description == "Supermarket and Grocery Stores" & 
           CLUE.small.area == "Melbourne (CBD)")
# Filter data to obtain car rental stores data 
car_data <- dataset %>%
  filter( Industry..ANZSIC4..description == "Passenger Car Rental and Hiring")

airport_data <- read.csv("melbourne_airports.csv")
# DMS conversion function: converts degrees, minutes, seconds (DMS) format to decimal degrees format
convert_dms_to_decimal <- function(dms) {
  match <- regmatches(dms, regexec("([0-9]+)°([0-9]+)′([0-9]+)″([NSEW])", dms))
  if (length(match[[1]]) == 5) {
    # Extract degrees, minutes, seconds and convert to numbers
    degrees <- as.numeric(match[[1]][2])
    minutes <- as.numeric(match[[1]][3])
    seconds <- as.numeric(match[[1]][4])
    direction <- match[[1]][5]
    
    decimal <- degrees + minutes / 60 + seconds / 3600
    if (direction %in% c("S", "W")) {
      decimal <- -decimal
    }
    return(decimal)
  }
  return(NA)
}

# Use the mutate() function to transform the Latitude and Longitude columns in the airport_data data frame.
airport_data <- airport_data %>%
  mutate(
    Latitude = sapply(Latitude, convert_dms_to_decimal),
    Longitude = sapply(Longitude, convert_dms_to_decimal)
  )

tram_data <- st_read("tram/PTV_METRO_TRAM_STOP.shp")
# Convert the coordinate system to WGS84 (EPSG:4326)
tram_data <- st_transform(tram_data, crs = 4326)

# processing tram data
tram_data_separated <- tram_data %>%
  separate_rows(ROUTEUSSP, sep = ",") %>%  
  mutate(ROUTEUSSP = trimws(ROUTEUSSP))  

train_data <- st_read("train/PTV_TRAIN_STATION_PLATFORM.shp")
# Convert the coordinate system to WGS84 (EPSG:4326)
train_data <- st_transform(train_data, crs = 4326)

bus_data <- st_read("bus/bus-stops.shp")
# Convert the coordinate system to WGS84 (EPSG:4326)
bus_data <- st_transform(bus_data, crs = 4326)
# Extract bus stop type
bus_data <- bus_data %>%
  mutate(bus_stop_type = gsub(".*Bus Stop Type (\\d+).*", "\\1", descriptio))  

# Create a color function to assign different colors to bus stops according to their type
pal1 <- colorFactor(palette = brewer.pal(8, "Dark2"), domain = bus_data$bus_stop_type)

location <- read.csv("Top_10_attractions_in_Melbourne.csv")

######################################################################################################
# Create a tab (tabPanel) that contains the map and user input options.
tab1 <- tabPanel("Map",
                 sidebarLayout(
                   # Contains user input options for setting the map display content
                   sidebarPanel(
                     # User input starting point
                     textInput("start_point", "Enter Starting Point:", value = "Melbourne"),
                     # User input destination
                     textInput("end_point", "Enter Destination:", value = "Melbourne CBD"),
                     # Get route button
                     actionButton("go_to_maps", "Get Directions"),
                     
                     # Facility Selection
                     checkboxInput("facilities", "Select Facilities:", value = FALSE),
                     conditionalPanel(
                       condition = "input.facilities == true",
                       checkboxGroupInput("facility_types", label = "Select facility type",
                                          choices = list("Toilets" = "toilets", 
                                                         "Restaurants" = "restaurants",
                                                         "Carparks" = "carparks",
                                                         "Accommodations" = "accommodations",
                                                         "Shops" = "shops",
                                                         "Tour Agency" = "tour agency"))
                     ),
                     # Transportation Selection
                     checkboxInput("transport", "Select transportation:", value = FALSE),
                     conditionalPanel(
                       condition = "input.transport == true",
                       checkboxGroupInput("transport_types", label = "Select transportation type",
                                          choices = list("Cars" = "car", 
                                                         "Airports" = "airport",
                                                         "Tram" = "tram",
                                                         "Train" = "train",
                                                         "Bus" = "bus"))
                     ),
                     # Location Selection
                     checkboxInput("location", "Top 10 locations", value = FALSE)
                   ),
                   # Display the map
                   mainPanel(
                     leafletOutput("map", height = 600)  
                   )
                 )
)
# Create a tab (tabPanel) called "Trip Details" to display trip details.
tab3 <- tabPanel("Trip Details",
                 sidebarLayout(
                   # The user selects the specific days of travel
                   sidebarPanel(
                     # Use the selectizeInput component to create a selection box for users to select a day.
                     selectizeInput("day", "Select Day:",
                                    choices = paste("Day", 1:7),
                                    options = list(
                                      placeholder = 'Choose a day...',
                                      onInitialize = I('function() { this.setValue(""); }')
                                    )
                     )
                   ),
                   # Main panel: contains two sub-tabs
                   mainPanel(
                     tabsetPanel(
                       # Subtab "Itinerary": Displays daily itinerary details
                       tabPanel("Itinerary",
                                uiOutput("itinerary")
                       ),
                       # Subtab "Expenditure": pie chart showing expenses
                       tabPanel("Expenditure",
                                plotlyOutput("pieChart")
                       )
                     )
                   )
                 )
)


# Create ui component for the Shiny app
ui <- navbarPage(
  "Melbourne Map",
  tab1,
  tab3
)


server <- function(input, output, session) {
  # Create the output logic of the map
  output$map <- renderLeaflet({
    # Initialize the map
    leaflet() %>%
      # Choose to use map type
      addProviderTiles("OpenStreetMap.HOT", group="OpenStreetMap HOT") %>% 
      addTiles() %>%
      setView(lng = 144.9631, lat = -37.8136, zoom = 12) # Set the initial view to Melbourne
  })
  
  # Dynamically locate a specific restaurant based on the `restaurant_id` parameter in the URL
  observe({
    query <- parseQueryString(session$clientData$url_search)
    if (!is.null(query$restaurant_id)) {
      restaurant_id <- query$restaurant_id
      
      # Filter out restaurant information matching the specified restaurant name from the restaurant_data dataset
      restaurant <- restaurant_data %>% filter(name == restaurant_id)
      
      # If a matching restaurant is found, update the map view and add a popup window to display the restaurant information
      if (nrow(restaurant) > 0) {
        leafletProxy("map") %>% 
          setView(lng = restaurant$longitude, lat = restaurant$latitude, zoom = 16) %>%
          addPopups(
            lng = restaurant$longitude, 
            lat = restaurant$latitude, 
            popup = paste0("<strong>", restaurant$name, "</strong><br>",
                           "<strong>Address:</strong> ", restaurant$address)
          )
      }
    }
  })
  
  observeEvent(input$facility_types, {
    # Get the facility selected by the user
    facilities <- input$facility_types
    
    # Initialize the map object
    map <- leafletProxy("map")
    map %>% clearMarkers()  # Clear existing markers
    
    # If a toilet is selected, add a toilet mark
    if("toilets" %in% facilities) {
      map %>% addMarkers(data = toilet_data, 
                         lng = ~lon, lat = ~lat, 
                         icon = icons(iconUrl = "icon/toilet-.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~name,
                         popup = ~paste0("Male: ", male, br(),
                                         "Female: ", female, br(),
                                         "wheelchair: ", wheelchair))
    }
    
    # If a restaurant is selected, add the restaurant mark
    if("restaurants" %in% facilities) {
      map %>% addMarkers(data = restaurant_data, 
                         lng = ~longitude, lat = ~latitude, 
                         icon = icons(iconUrl = "icon/restaurant.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = lapply(seq_along(restaurant_data$name), function(i) {
                           HTML(paste0("<strong>Name:</strong> ", restaurant_data$name[i], "<br>",  
                                       "<strong>Rank:</strong> ", restaurant_data$rankingPosition[i], "<br>",
                                       "<strong>Price Level:</strong> ", restaurant_data$priceLevel[i], "<br>",
                                       "<strong>Rating:</strong> ", restaurant_data$rating[i]))
                         }),
                         popup = ~paste0("<strong>Address:</strong> ", address, "<br>",  
                                         "<strong>Detail:</strong> ", details))
    }
    
    # If carpark is selected, add the carpark mark
    if("carparks" %in% facilities) {
      map %>% addMarkers(data = carpark_data_filtered, 
                         lng = ~Longitude, lat = ~Latitude, 
                         icon = icons(iconUrl = "icon/carpark.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~Building.address,
                         popup = ~paste0("<strong>Parking Type:</strong> ", Parking.type, "<br>",
                                         "<strong>Parking Space:</strong> ", Parking.spaces))
    }
    
    # If accommodation is selected, add accommodation mark
    if("accommodations" %in% facilities) {
      map %>% addMarkers(data = accommodation_data, 
                         lng = ~longitude, lat = ~latitude, 
                         icon = icons(iconUrl = "icon/hotel.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~trading_name,
                         popup = ~paste0("<strong>Address:</strong>", building_address))
    }
    
    # If a shop is selected, add the shop mark
    if("shops" %in% facilities) {
      map %>% addMarkers(data = shop_data, 
                         lng = ~Longitude, lat = ~Latitude, 
                         icon = icons(iconUrl = "icon/shopping-cart.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~Trading.name,
                         popup = ~paste0("<strong>Address:</strong>", Business.address, "<br>",
                                         "<strong>Description:</strong>", Industry..ANZSIC4..description))
    }
    
    # If travel agency is selected, add the travel agency mark
    if("tour agency" %in% facilities) {
      map %>% addMarkers(data = tour_agency_data, 
                         lng = ~Longitude, lat = ~Latitude, 
                         icon = icons(iconUrl = "icon/travel-agency.png", iconWidth = 30, iconHeight = 30),
                         label = ~Trading.name,
                         popup = ~paste0("<strong>Address:</strong>", Business.address, "<br>",
                                         "<strong>Description:</strong>", Industry..ANZSIC4..description))
    }
  })
  
  # Transportation
  observeEvent(input$transport_types, {
    transport <- input$transport_types
    map <- leafletProxy("map")
    map %>% clearMarkers()  
    
    # If you choose to drive, add a car rental point mark
    if("car" %in% transport) {
      map %>% addMarkers(data = car_data, 
                         lng = ~Longitude, lat = ~Latitude, 
                         icon = icons(iconUrl = "icon/vehicle.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~Trading.name,
                         popup = ~paste0("<strong>Address:</strong>", Business.address, "<br>",
                                         "<strong>Description:</strong>", Industry..ANZSIC4..description))
    }
    
    # If a plane is selected, add an airport mark
    if("airport" %in% transport) {
      map %>% addMarkers(data = airport_data, 
                         lng = ~Longitude, lat = ~Latitude, 
                         icon = icons(iconUrl = "icon/airplane.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~Airport_name,
                         popup = ~paste0("<strong>Community:</strong>", Community, "<br>",
                                         "<strong>Type:</strong>", Type))
    }
    # If a plane is selected, add an airport mark
    if ("train" %in% transport) {
      map %>% addPolygons(data = train_data,
                          fillColor = ~ifelse(is.na(PLATFORM), "grey", "blue"),  # Set fill color
                          color = "black",
                          weight = 1,
                          opacity = 0.7,
                          fillOpacity = 0.5,
                          # Highlight effect when the mouse is hovering
                          highlightOptions = highlightOptions(weight = 3, color = "white", fillOpacity = 0.7),  
                          popup = ~paste("Station: ", STATION, "<br>", "Platforms: ", PLATFORM))
    }
    
    # If tram is selected, add the tram mark
    if("tram" %in% transport) {
      pal_tram <- colorFactor(palette = viridis(10), domain = tram_data$ROUTEUSSP)
      map %>% addCircleMarkers(data = tram_data_separated,
                               lng = ~LONGITUDE, lat = ~LATITUDE,
                               color = ~pal_tram(ROUTEUSSP),
                               fillOpacity = 0.7,
                               radius = 6,
                               label = ~paste("Route: ", ROUTEUSSP),
                               labelOptions = labelOptions(direction = "auto"),
                               popup = ~paste0(strong("Stop Name: "), STOP_NAME, br(),
                                               strong("Ticket Zone: "), TICKETZONE),
                               group = ~ROUTEUSSP) %>%
        # Add a selection box for each route
        addLayersControl(
          overlayGroups = unique(tram_data_separated$ROUTEUSSP),
          options = layersControlOptions(collapsed = TRUE)
        )
    }
    # If bus is selected, add bus mark
    if("bus" %in% transport) {
      pal_bus <- colorFactor(palette = brewer.pal(8, "Dark2"), domain = bus_data$bus_stop_type)
      map %>% addCircleMarkers(data = bus_data,
                               lng = st_coordinates(bus_data)[, 1], 
                               lat = st_coordinates(bus_data)[, 2],  
                               color = ~pal_bus(bus_stop_type),
                               fillOpacity = 0.7,
                               radius = 8,  # Increase the radius for better display
                               label = ~paste("Stop type: ", bus_stop_type),
                               labelOptions = labelOptions(direction = "auto"),
                               popup = ~paste("Bus Stop Type:", bus_stop_type, "<br>",
                                              "Asset Type:", asset_type),
                               group = ~bus_stop_type) %>%
        # Add a selection box for each bus stop type
        addLayersControl(
          overlayGroups = unique(bus_data$bus_stop_type),
          options = layersControlOptions(collapsed = TRUE)
        )
    }
  })
  
  # Top 10 popular locations
  observeEvent(input$location, {
    if(input$location) {
      map <- leafletProxy("map")
      map %>% addMarkers(data = location, 
                         ~Longitude, ~Latitude, 
                         icon = icons(iconUrl = "icon/pin.png", 
                                      iconWidth = 30, iconHeight = 30),
                         label = ~Attraction, 
                         popup = ~paste0("<b>Rank: </b>", Rank, "<br>",
                                         "<b>Visitor Number: </b> ", Visitor_number, "<br>",
                                         "<b>Description: </b>", Description)  
      )
    }
  })
  
  # Respond to "Get Directions" button click
  observeEvent(input$go_to_maps, {
    req(input$start_point, input$end_point)  # Make sure you enter the start and end points
    url <- paste0("https://www.google.com/maps/dir/?api=1&origin=", URLencode(input$start_point), "&destination=", URLencode(input$end_point))
    browseURL(url)  # Open the URL in the browser
  })
  
  ######################################################### Tab3 ######################################################################################
  # Create a reactive function 'itinerary' that returns the itinerary for the day selected by the user.
  itinerary <- reactive({
    # Get the number of days selected by the user in the input box
    day_selected <- input$day
    # Return the corresponding itinerary according to the selected days. Each day's itinerary includes the name and description of the attractions.
    switch(day_selected,
           "Day 1" = list(
             h3("Explore Melbourne's Urban Charm:"), # Set title
             wellPanel(
               # Create an unordered list
               tags$ul( 
                 tags$li(a("Federation Square", href = "https://fedsquare.com/"), " - Melbourne's cultural hub, often hosting art exhibitions and events."),
                 tags$li(a("St Paul's Cathedral", href = "https://cathedral.org.au/"), " - A beautiful Gothic cathedral offering a serene atmosphere."),
                 tags$li(a("Flinders Street Station", href = "https://whatson.melbourne.vic.gov.au/things-to-do/flinders-street-railway-station"), " - An iconic railway station known for its distinctive architecture."),
                 tags$li(a("Melbourne Town Hall", href = "https://whatson.melbourne.vic.gov.au/things-to-do/melbourne-town-hall-tours"), " - A historic town hall that frequently hosts cultural events and concerts."),
                 tags$li(a("City Circle Tram Tour", href = "https://www.ptv.vic.gov.au/route/15834/35/"), " - A free tourist tram that loops around the CBD, making it easy to see key sights."),
                 tags$li(a("State Library Victoria", href = "https://www.slv.vic.gov.au/"), " - An impressive library featuring a magnificent reading room.")
               )
             )
           ),
           "Day 2" = list(
             h3("A Day in Southbank:"),
             wellPanel(
               tags$ul(
                 tags$li(a("Crown Casino and Entertainment Complex", href = "https://www.crownmelbourne.com.au/"), " - A large casino and entertainment venue with dining and entertainment options."),
                 tags$li(a("Eureka Skydeck", href = "https://www.melbourneskydeck.com.au/"), " - An observation deck offering panoramic views of the city, great for photos."),
                 tags$li(a("Southbank Promenade", href = "https://www.visitmelbourne.com/Regions/Melbourne/Destinations/Southbank-and-South-Wharf"), " - A scenic riverside walkway perfect for strolls and dining."),
                 tags$li(a("Arts Centre Melbourne", href = "https://www.artscentremelbourne.com.au/visit/things-to-do"), " - A cultural center showcasing a variety of performances and exhibitions."),
                 tags$li(a("DFO South Wharf", href = "https://www.south-wharf.dfo.com.au/"), " - A shopping outlet offering many discount brands and fashion options.")
               )
             )
           ),
           "Day 3" = list(
             h3("Fitzroy & Carlton Adventures:"),
             wellPanel(
               tags$ul(
                 tags$li(a("Queen Victoria Market", href = "https://qvm.com.au/"), " - A bustling market offering fresh produce, crafts, and souvenirs."),
                 tags$li(a("Melbourne Museum", href = "https://museumsvictoria.com.au/MelbourneMuseum/"), " - A museum showcasing natural history and human culture, great for families."),
                 tags$li(a("Royal Exhibition Building & Carlton Gardens", href = "https://museumsvictoria.com.au/reb/plan-your-visit/"), " - A UNESCO World Heritage site surrounded by beautiful gardens."),
                 tags$li(a("Chinatown on Little Bourke Street", href = "https://chinatownmelbourne.com.au/"), " - A multicultural district filled with restaurants and shops."),
                 tags$li(a("Brunswick Street", href = "https://weknowmelbourne.com.au/brunswick-street-guide/"), " - Famous for its cafe culture, featuring many trendy cafes and shops.")
               )
             )
           ),
           "Day 4" = list(
             h3("Relaxation in St Kilda:"),
             wellPanel(
               tags$ul(
                 tags$li(a("St Kilda Beach", href = "https://stkildamelbourne.com.au/things-to-do-see/beach-outdoors/"), " - A popular beach for sunbathing and water activities."),
                 tags$li(a("Luna Park", href = "https://lunapark.com.au/"), " - An iconic amusement park with fun rides and a classic ferris wheel."),
                 tags$li(a("Acland Street", href = "https://aclandstreetvillage.com.au/"), " - Renowned for its cafes and pastry shops, perfect for food lovers."),
                 tags$li(a("St Kilda Pier", href = "https://www.parks.vic.gov.au/places-to-see/parks/st-kilda-pier-and-breakwater"), " - A picturesque pier where you can spot little penguins at sunset."),
                 tags$li(a("Chapel Street", href = "https://www.chapelstreet.com.au/"), " - A vibrant shopping street with trendy boutiques and dining options.")
               )
             )
           ),
           "Day 5" = list(
             h3("Great Ocean Road Day Trip:"),
             wellPanel(
               tags$ul(
                 tags$li(a("Twelve Apostles", href = "https://www.australia.com/en/places/melbourne-and-surrounds/guide-to-the-12-apostles.html"), " - Famous limestone stacks offering breathtaking natural scenery."),
                 tags$li(a("Loch Ard Gorge", href = "https://www.getyourguide.com/loch-ard-gorge-l117610/"), " - A stunning beach and dramatic cliffs, great for photos and exploration."),
                 tags$li(a("Apollo Bay", href = "https://visitapollobay.com/"), " - A picturesque town ideal for resting and enjoying fresh seafood."),
                 tags$li(a("Great Otway National Park", href = "https://www.parks.vic.gov.au/places-to-see/parks/great-otway-national-park?utm_source=tripadvisor.com.au&utm_medium=referral&utm_campaign=TA-2020"), " - A forest park with abundant wildlife and hiking trails."),
                 tags$li(a("Bells Beach", href = "https://torquaylife.com.au/explore/bells-beach/"), " - A renowned surfing spot, perfect for surfers and sightseers alike.")
               )
             )
           ),
           "Day 6" = list(
             h3("Yarra Valley Excursions:"),
             wellPanel(
               tags$ul(
                 tags$li(a("Healesville Sanctuary", href = "https://www.zoo.org.au/healesville"), " - A wildlife sanctuary focusing on Australian native animals, perfect for families."),
                 tags$li(a("Yarra Valley Wineries", href = "https://yarravalleywineries.com.au/"), " - A famous wine region known for tastings and gourmet dining."),
                 tags$li(a("Puffing Billy Railway (optional)", href = "https://puffingbilly.com.au/"), " - A classic steam train journey through scenic mountain landscapes."),
                 tags$li(a("Dandenong Ranges", href = "https://www.visityarravalley.com.au/discover/dandenong-ranges"), " - Beautiful mountains ideal for hiking and nature exploration.")
               )
             )
           ),
           "Day 7" = list(
             h3("Brighton & Beyond:"),
             wellPanel(
               tags$ul(
                 tags$li(a("Brighton Beach Boxes", href = "https://www.brightonbathingbox.org.au/"), " - Colorful beach huts that are perfect for photos and leisurely strolls."),
                 tags$li(a("Phillip Island for Penguin Parade", href = "https://www.phillip-island-tours.com/phillip-island-penguin-parade-tickets/?gad_source=1&gclid=Cj0KCQjwsc24BhDPARIsAFXqAB3FFB9WUpPjOhiIByl6mwUviDMYY2fmmJcSnu0fXtN7k3Rmer_kW5UaAiKqEALw_wcB"), " - A unique experience watching cute little penguins return to shore."),
                 tags$li(a("Moonlit Sanctuary Wildlife Conservation Park", href = "https://moonlitsanctuary.com.au/?srsltid=AfmBOoo-bNRLH45r01DSVwn-Xp13prWVmYf4BXoDzm09coyEPX_U4Vhe"), " - A wildlife park where you can get up close with Australian animals."),
                 tags$li(a("Morning hot air balloon ride over the city", href = "https://www.globalballooning.com.au/christmas/?gad_source=1&gclid=Cj0KCQjwsc24BhDPARIsAFXqAB1Py2WwedJxY0KeQACBpCn0EnCErvEm4c5dwTVXbXsmRcPZ5EjrqJgaAslmEALw_wcB"), " - A breathtaking experience to see Melbourne from above.")
               )
             )
           ),
           list(h3("Please select a valid day!"))
    )
  })
  
  # Render the UI output of the trip, presenting the content generated by the reactive 'itinerary' in the UI.
  output$itinerary <- renderUI({
    itinerary()  # Dynamically generate HTML content for itinerary
  })
  
  # Load and preprocess data
  data <- reactive({
    # Read the data from the CSV file
    df <- read.csv("Total trip expenditure by item of expenditure by main reason for travel.csv")
    
    # Clean the 'Total' column and convert it to numeric
    df$Total <- as.numeric(gsub(",", "", df$Total))
    
    # Remove the last row (the total row)
    df <- df[-nrow(df), ]
    
    return(df)
  })
  
  # Render the pie chart
  output$pieChart <- renderPlotly({
    fig <- plot_ly(data(), labels = ~Expenditure...M., values = ~Total, type = 'pie',
                   textinfo = 'label+percent', hoverinfo = 'label+value+percent',
                   marker = list(line = list(color = '#FFFFFF', width = 1)))
    
    # Add title and layout with margin
    fig <- fig %>%
      layout(title = list(text = 'Total Expenditure Breakdown by Category',
                          font = list(size = 20)),
             margin = list(l = 50, r = 50, t = 100, b = 50),  # Adjust margins
             showlegend = TRUE)
    
    return(fig)
  })
}

shinyApp(ui, server, options=list(port=6245))
